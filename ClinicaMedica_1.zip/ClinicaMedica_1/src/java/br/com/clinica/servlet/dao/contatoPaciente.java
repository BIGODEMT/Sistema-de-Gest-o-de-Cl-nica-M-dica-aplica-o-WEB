package br.com.clinica.servlet.dao;

import br.com.clinica.servlet.model.adicionarPaciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class contatoPaciente {

    private final Connection connection;

    public contatoPaciente(Connection connection) {
        this.connection = connection;
    }

    // Método para cadastrar paciente
    public void cadastrarPaciente(adicionarPaciente paciente) {
        String sql = "INSERT INTO paciente (nome, telefone, cpf, data_nascimento) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getTelefone());
            stmt.setString(3, paciente.getCpf());
            stmt.setString(4, paciente.getDataNascimento());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao cadastrar paciente", e);
        }
    }

    // Método para listar pacientes
    public List<adicionarPaciente> listarPacientes() {
        String sql = "SELECT nome, telefone, cpf, data_nascimento FROM paciente";
        List<adicionarPaciente> pacientes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                pacientes.add(new adicionarPaciente(
                        rs.getString("nome"),
                        rs.getString("telefone"),
                        rs.getString("cpf"),
                        rs.getString("data_nascimento")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar pacientes", e);
        }
        return pacientes;
    }
}
