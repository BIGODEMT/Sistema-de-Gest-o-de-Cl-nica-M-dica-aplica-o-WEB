package br.com.clinica.servlet.dao;

import br.com.clinica.servlet.model.adicionarMedico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class contatoMedico {

    private final Connection connection;

    public contatoMedico(Connection connection) {
        this.connection = connection;
    }

    // Método para cadastrar médico
    public void cadastrarMedico(adicionarMedico medico) {
        String sql = "INSERT INTO medico (nome, telefone, crm, especialidade) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, medico.getNome());
            stmt.setString(2, medico.getTelefone());
            stmt.setString(3, medico.getCrm());
            stmt.setString(4, medico.getEspecialidade());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao cadastrar médico", e);
        }
    }

    // Método para listar médicos
    public List<adicionarMedico> listarMedicos() {
        String sql = "SELECT nome, telefone, crm, especialidade FROM medico";
        List<adicionarMedico> medicos = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                medicos.add(new adicionarMedico(
                        rs.getString("nome"),
                        rs.getString("telefone"),
                        rs.getString("crm"),
                        rs.getString("especialidade")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar médicos", e);
        }
        return medicos;
    }
}
