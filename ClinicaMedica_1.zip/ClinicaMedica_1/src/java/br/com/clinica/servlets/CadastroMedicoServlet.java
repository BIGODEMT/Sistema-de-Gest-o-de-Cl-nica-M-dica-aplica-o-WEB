package br.com.clinica.servlets;

import br.com.clinica.servlet.connection.conexãoFactory;
import br.com.clinica.servlet.dao.contatoMedico;
import br.com.clinica.servlet.model.adicionarMedico;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/cadastroMedicoServlet")
public class CadastroMedicoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nome = request.getParameter("nome");
        String telefone = request.getParameter("telefone");
        String crm = request.getParameter("crm");
        String especialidade = request.getParameter("especialidade");

        // Validação simples
        if (nome == null || nome.isEmpty() || telefone == null || telefone.isEmpty() || crm == null || crm.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Campos obrigatórios não preenchidos.");
            return;
        }

        // Criação do modelo
        adicionarMedico medico = new adicionarMedico(nome, telefone, crm, especialidade);

        // Tentando inserir o médico no banco
        try (Connection connection = conexãoFactory.getConnection()) {
            contatoMedico dao = new contatoMedico(connection);
            dao.cadastrarMedico(medico);

            // Resposta para o cliente
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("<html><body>Registro " + medico.getNome() + " adicionado com sucesso!</body></html>");
        } catch (SQLException e) {
            Logger.getLogger(CadastroMedicoServlet.class.getName()).log(Level.SEVERE, "Erro ao cadastrar médico", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao processar a solicitação.");
        }
    }
}
