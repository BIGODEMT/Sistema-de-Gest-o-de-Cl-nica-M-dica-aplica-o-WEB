package br.com.clinica.servlets;

import br.com.clinica.servlet.connection.conexãoFactory;
import br.com.clinica.servlet.dao.contatoPaciente;
import br.com.clinica.servlet.model.adicionarPaciente;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/cadastroPacienteServlet")
public class CadastroPacienteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtendo os parâmetros do formulário HTML
        String nome = request.getParameter("nome");
        String telefone = request.getParameter("telefone");
        String cpf = request.getParameter("cpf");
        String dataNascimento = request.getParameter("data_nascimento");

        // Validação simples dos dados
        if (nome == null || nome.isEmpty() || telefone == null || telefone.isEmpty() || cpf == null || cpf.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Campos obrigatórios não preenchidos.");
            return;
        }

        // Criando a instância do modelo "adicionarPaciente"
        adicionarPaciente paciente = new adicionarPaciente(nome, telefone, cpf, dataNascimento);

        // Tentando inserir o paciente no banco de dados
        try (Connection connection = conexãoFactory.getConnection()) {
            // Criando o DAO de Paciente
            contatoPaciente dao = new contatoPaciente(connection);
            // Cadastrando o paciente no banco
            dao.cadastrarPaciente(paciente);

            // Resposta para o usuário com o nome do paciente cadastrado
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("<html><body>");
            response.getWriter().println("Registro do paciente " + paciente.getNome() + " adicionado com sucesso!");
            response.getWriter().println("</body></html>");
        } catch (SQLException e) {
            // Log de erro no servidor
            Logger.getLogger(CadastroPacienteServlet.class.getName()).log(Level.SEVERE, "Erro ao cadastrar paciente", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao processar a solicitação.");
        }
    }
}
